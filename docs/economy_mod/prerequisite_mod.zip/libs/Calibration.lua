-- Copyright © 2008-2021 Pioneer Developers. See AUTHORS.txt for details
-- Licensed under the terms of the GPL v3. See licenses/GPL-3.txt

local Calibration = {}

Calibration.StockPriceOne = 10^9 --On low prices rn are large integers that can not exceed much the 2    *10^9 anyway. See function updateEquipmentStock in SpaceStation.lua
Calibration.PriceExponential = 2.42328282947206

print("----------------------------------")
print(Calibration.StockPriceOne, Calibration.PriceExponential)
print("--------StockOne, PriceExp--------")
return Calibration 
